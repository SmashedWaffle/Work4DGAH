label narration:
    scene bg uni with fade 
    "Narration: Time: 10:15 am Date: November 22, 205 Objective: Find and talk to Professor Mac. Location: Solis lab" 
    show You shocked with fade 
    u "Wowwww talk about impressive yet so crowded! Hopefully I can find Professor Mac before it’s too late."
menu: 
    "Explore gym."
    "Explore door with 2 key card scanners."
    "Explore pool."

    "Explore gym.":
        jump Explore_gym
    "Explore door with 2 key card scanners.":
        jump Explore_door_with_2_key_card_scanners
    "Explore pool.":
        jump Explore_pool_fake

label Explore_gym:
    u "Hmmm a gym? I haven't been there in months. Better late than never right?" 
    show bg meadow with fade
    show You natural with fade
    b "HEY HEYYYYY! You, yes you."
    u "Umm who, me?"
    show Mike happy with fade 
    b "No, the gorilla standing behind you. OFC you, don't you remember you ass."
    show You shocked 
    u "Omg! Mike is that you?"
    show Mike smug 
    b "Nahhhh, my name is Brock. Duhhh, it’s me Mike who else you know has biceps these big?"

menu: 
    "Compliment his muscles."
    "Flex your muscles and brag."

    "Compliment his muscles.":
        jump Compliment_his_muscles
    "Flex your muscles and brag.":
        jump Flex_your_muscles_and_brag

label Compliment_his_muscles: 
    u "Haha That’s true you sure got some guns on you! But what are you doing here at the Solis’s lab gym?"
    show You normal 
    show Mike noraml
    jump Mike_lore

label Flex_your_muscles_and_brag: 
    u "Easy answer me and I haven't even gone to the gym! But what are you doing here at the Solis’s lab gym?"
    show You normal 
    show Mike normal
    jump Mike_lore 

label Mike_lore:
    b "Well, I just turned 18 and my dad said I had to come here because something about me being a monster hunter or whatever. I just came because I heard the Solis gym is wicked sick, which it is."
    show You excited
    u "ME TOO! Omg I just wanted to sleep in but my mom forced me to come so here I am. If your down, I am just to go meet with Professor Mac right now."
    show You normal 
    b "Ehhh sure, I just finished my work out, these bad boys aren’t gonna get any big!"

    scene bg restricted door with fade 

    show You normal 
    show Mike normal 

    b "This is it!"

menu: 
    "Question Mike about the warning signs."
    "Question Mike about the key cards for the the door."

    "Compliment his muscles.":
        jump Question_Mike_about_the_warning_signs
    "Question Mike about the key cards for the the door.":
        jump Question_Mike_about_the_key_cards_for_the_the_door

label Question_Mike_about_the_warning_signs:
    show You scared 
    show Mike smug
    u "Ummm Mike not acting like a scaredy cat, but this door has a ton of warning signs. What’s the deal with that?"
    b "Ohhh that dont worry buddy you're gonna be fine I promise!"
    jump Question_Mike_about_the_key_cards_for_the_the_door

label Question_Mike_about_the_key_cards_for_the_the_door:
    show You normal 
    show Mike smug
    u "Mike not sure if you have notice but you need 2 key cards to get in?"
    b "DUHHHHHH, short stack. You think I’m blind or something? I got my key card right here! But dam forgot Millie has the other?"
    show You thinking 
    u "Millie? She works here? I haven't seen her since I was like 12. "
    show Mike laugh
    b "Perfect, now you can catch up then! Hopefully, she doesn’t bit your head off for not staying in contact *HAHA*. Ohhh and before I forget here it my keycard."
    show you nomral
    u "I was always more responsible with things!"
    $ inventory.append("Key card 1")
    jump Explore_pool_real


label Explore_door_with_2_key_card_scanners:
    scene bg restricted door with fade 
    show You normal
    u "Hmmm, a big door with a warning sign. Looks interesting. Should definitely try opening it."
    "You tug on the door. It creaks and bends a bit but remains close. You need 2 key cards."

menu: 
    "Explore gym."
    "Explore pool."

    "Explore gym.":
        jump Explore_gym
    "Explore pool.":
        jump Explore_pool_fake

label Explore_pool_fake:
    show You thinking
    u "A pool? Last time I went was when I was 12. I would always go with Millie. We would play Marco Polo. I wonder what happened to her? Might as well check it out for old time sake." 
    scene bg pool doors closed 
    u "Awww what the pool is closed until 10:30. Guess I will come back after."

menu: 
    "Explore gym."
    "Explore door with 2 key card scanners."

    "Explore gym.":
        jump Explore_gym
    "Explore door with 2 key card scanners.":
        jump Explore_door_with_2_key_card_scanners


label Explore_pool_real:
    show You thinking
    scene bg pool 
    u "I must be thinking about Millie too much now because that life guard kinda looks like her. Wait, could it really be?" 

menu: 
    "Yell out Millie."
    "Slowly approach girl."

    "Yell out Millie.":
        jump Yell_out_Millie
    "Slowly approach girl.":
        jump Slowly_approach_girl

label Slowly_approach_girl:
    show You shy
    u "*whispering* ummm…..excuse me….Millie. Excuse me, it me Millie." 
    jump Yell_out_Millie
    
label Yell_out_Millie: 
    show You scream
    u "MILLLIEEEEEEEEEEEEEEEE. OVER HERRRRE!"
    show you normal
    u "Mill’s it me. Don’t you remember we would always hang out at the rec center pool when we were younger."
    show Millie shocked 
    g "Well, I’ll be! Where in tarnation ya been? Ain't seen your face since summer, an' that feels like 6 summers ago!"
    show you shy
    u "Ermmmmm maybeeee. No hard feelings though right!"
    show You normal 
    show Millie normal
    g "Nahhh none at all."
    u "Haha perfect because you're one person I don’t wanna be on the bad side of!"
    show Millie pout 
    g "WELL, HUSH NOW! Just so ya know, I'm a real sweet gal, so I’ve heard. Anyhow, what are you doing here?"

menu: 
    "Tell Millie you need her for her keycard."
    "Tell Millie you forgot why."

    "Tell Millie you need her for her keycard.":
        jump Tell_Millie_you_need_her_for_her_keycard
    "Tell Millie you forgot why.":
        jump Tell_Millie_you_forgot_why

label Tell_Millie_you_forgot_why: 
    show You thinking 
    show Millie normal 
    u "Ummmm, honestly Millie I may have forgotten haha. Your yelling scared me to the point of forgetting."
    show Millie pout
    g "Pointed them fingers at me for yer messes, sugar. Oughta take some responsibility. Anyhow, the only reason folks ever wander 'round here is 'cause they're becoming monster hunters, is that it?"
    show You excited
    u "YA, YA, that’s it." 
    jump Tell_Millie_you_need_her_for_her_keycard


label Tell_Millie_you_need_her_for_her_keycard: 
    show You normal 
    show Millie normal 
    u "I was supposed to meet Professor Mac about something of me becoming a monster hunter, but I need your keycard to access the door."
    show Millie happy
    g "Well, why didn’t ya just say so, honey! I’ll haul ya over to him right this minute, no need to fret!"
    $ inventory.append("Key card 2")
    jump Main_story_big_doors

label Main_story_big_doors: 
    scene bg restricted door
    show Mike smug
    show Millie pout
    b "Heyyyyy Millie, surprised you didn’t bite off his head!"
    g "Mike watch your mouth before your head is the one getting bitten off!"
    b "I tell You I don’t know how you even made it out with Mill’s. Me and her would have a problem and kill each other!"

menu: 
    "Agree with Mike."
    "Defend Millie."

    "Agree with Mike.":
        jump Agree_with_Mike
    "Defend Millie.":
        jump Defend_Millie

label Agree_with_Mike:
    show You happy
    u "Haha Your a ladies man Mike just not Millie’s ladies man."
    show Mike happy
    b "I know that’s right!"
    jump Middle_main

label Defend_Millie: 
    show you normal
    u "Mike come on, joking with me is okay. But you know Millie hates it. Better stop before she actually does."
    show Millie happy
    g "Awww thank you!"
    jump Middle_main

label Middle_main: 
    show Mike normal
    show You normal 
    show Millie normal
    b "Anyhow, let's hurry up and get you to Professor Mac, it’s already 11:30!"
    "You swipe Millie's and Mike's key cards."

    scene Solis lab with fade 
    show Prof Mac happy 
    p "I have been expecting you three! About time y’all showed up I was worried all the fumes I have been inhaling were making me forget if we ever met!"
    p "Lets get you started on being a monster hunter, chap! All  three capsules have different types of monster’s. Go ahead, don't be shy, pick one. Be aware once you choose you are stuck with them! No pressure."

menu: 
    "Green monster capsule."
    "Red monster capsule."
    "Purple monster capsule."

    "Green monster capsule.":
        jump Green_monster_capsule
    "Red monster capsule.":
        jump Red_monster_capsule
    "Purple monster capsule.":
        jump Purple_monster_capsule

label Green_monster_capsule:
    show You thinking 
    u "I choose, hmmm, so hard to decide. I chose green!"
    p "Excellent choice! Open it up!"
    show you shocked
    u "WHAAAAAAT! Prof. Mac this capsule is Empty!"
    show Prof Mac smug
    p "Ohhhh hoho! I guess these toxic fumes from the lab are getting to me. I forgot to mention other kid who came much earlier had already took them."
    show Mike laugh 
    b "HAHAAHA. Sucks for youuuuuu. Try another!"

menu: 
    "Red monster capsule."
    "Purple monster capsule."

    "Red monster capsule.":
        jump Red_monster_capsule
    "Purple monster capsule.":
        jump Purple_monster_capsule

label Purple_monster_capsule: 
    show You thinking 
    u "I choose, hmmm, so hard to decide. I chose purple!"
    p "Excellent choice! Open it up!"
    show you shocked
    u "WHAAAAAAT! Prof. Mac this capsule is Empty!"
    show Prof Mac smug
    p "Ohhhh hoho! I guess these toxic fumes from the lab are getting to me. I forgot to mention other kid who came much earlier had already took them."
    show Mike laugh 
    b "HAHAAHA. Sucks for youuuuuu. Try another!"

menu: 
    "Red monster capsule."
    "Green monster capsule."

    "Red monster capsule.":
        jump Red_monster_capsule
    "Green monster capsule.":
        jump Green_monster_capsule

label Red_monster_capsule:
    show You thinking 
    u "I choose, hmmm, so hard to decide. I chose red!"
    p "Excellent choice! Open it up!"
    show you shocked
    u "Woahhhh it looks so cool!!!"
    $ inventory.append("Infernox")
    show Prof Mac happy
    p "His name is Infernox, a fire type monster. Well I guess we should get on to what you do now that you have a monster."
    show You think 
    u "Umm Prof. Mac I think I got it my mom said I have to go hunt monsters and either capture to make them into my pet or food! It that right?"
    p "Ehhh close enough go out there and have some fun!"
    jump Last_middle

label Last_middle:
    show Prof Mac normal 
    p "Ohh before I forget I have few things to tell you about. Which do you wanna learn about first:"
    p "Bones-bones are a great way to reward any pets for good behavior besides that not used for much else."
    p "Monster capsules-portable capsules you can carry to capture any monsters you deem worth of keeping over cooking!"
    p "Scanner-allow you to find monsters even in the highest and tallest grass."
    p "Fishing bait-Kind of self explanatory but allows for you to hunt those pesky hidden underwater monsters."
    p "Cooking kit-Ahhh, the most important. Use to make delicious meals from even delicious monsters."
    show You normal
    u "Okayyyy Prof. Mac enough yapping can we goooo now!"
    p " I suppose but here take all these you're gonna need them! Now go out and have fun!"
    $ inventory.append("Bones")
    $ inventory.append("Capsules")
    $ inventory.append("Scanner")
    $ inventory.append("Bait")
    $ inventory.append("cook kit")
    jump Near_conclusion_1

