﻿# Setup and Introduction
# Player and opponent stats and selection variables
default player_hp = 100
default player_max_hp = 100
default opponent_hp = 100
default opponent_max_hp = 100
default player_creature = ""  # Will be set during selection

## Characters

define u = Character("Me", color="#000000")
define g = Character("Millie", color="#1bdedeff")
define b = Character("Mike", color="#ff0077b5")
define m = Character("Mom", color="#14aa50e8")
define p = Character("Professor Mac", color="#bd810ae8")


# Game state variables
default inventory = []
screen inventory():
    frame:
        xalign 0.95 yalign 0.02
        if inventory:
            text "Inventory: [', '.join(inventory)]"
        else:
            text "Inventory: Empty"

#battle screen(s)
screen battle_interface1():
    modal True
    tag battle

    # Opponent Monster (top-right)
    add "snake.png" xalign .85 yalign .1

    # Opponent's HP bar (top-right)
    frame:
        xalign .95
        yalign 0.05
        background "#0009"
        padding (10, 5, 10, 5)  # left, top, right, bottom
        vbox:
            text "Monster" color "#ffffff" size 18
            bar value opponent_hp range opponent_max_hp xalign 0.0 yalign 0.1 xmaximum 200

    # Player's HP bar (bottom-left)
    frame:
        xalign 0.05
        yalign .75
        background "#0009"
        padding (10, 5, 10, 5)
        vbox:
            text "Infernox's HP" color "#FFF" size 18
            bar value player_hp range player_max_hp xalign 0.0 yalign 0.1 xmaximum 200

    # Battle options menu (centered)
    frame:
        xalign 0.5
        yalign 0.55
        background "#0009"
        padding (10, 10, 10, 10)
        hbox spacing 30:
            textbutton "Attack" action Return("Attack") text_color "#c92e2ed5"
            textbutton "Spare" action Return("Spare") text_color "#1bda54e0"
            textbutton "Capture" action Return("Capture") text_color "#bc17cf"
            textbutton "Run" action Return("Run") text_color "#ffffff"

screen battle_interface2():
    modal True
    tag battle

    # Opponent Monster (top-right)
    add "crab.png" xalign .85 yalign .1

    # Opponent's HP bar (top-right)
    frame:
        xalign .95
        yalign 0.05
        background "#0009"
        padding (10, 5, 10, 5)  # left, top, right, bottom
        vbox:
            text "Monster" color "#ffffff" size 18
            bar value opponent_hp range opponent_max_hp xalign 0.0 yalign 0.1 xmaximum 200

    # Player's HP bar (bottom-left)
    frame:
        xalign 0.05
        yalign .75
        background "#0009"
        padding (10, 5, 10, 5)
        vbox:
            text "Infernox's HP" color "#FFF" size 18
            bar value player_hp range player_max_hp xalign 0.0 yalign 0.1 xmaximum 200

    # Battle options menu (centered)
    frame:
        xalign 0.5
        yalign 0.55
        background "#0009"
        padding (10, 10, 10, 10)
        hbox spacing 30:
            textbutton "Attack" action Return("Attack") text_color "#c92e2ed5"
            textbutton "Spare" action Return("Spare") text_color "#1bda54e0"
            textbutton "Capture" action Return("Capture") text_color "#bc17cf"
            textbutton "Run" action Return("Run") text_color "#ffffff"



#orginially the creature selection was here but has then been moved to the prof part 

#Above is the control code and below is the intro 

# The game starts here. aka ## --- Labels (Scenes) ---

label start:
    show screen inventory
    scene bg intro with fade
    "Narration: Time: 9:30 am Date: November 22, 205 Occasion: Your 18th birthday Location: Home"
    show mom excited with fade 
    m "Mom: RISEEEEEE AND SHINEEEEE HUN. It’s your 18th birthdayyyyy! That a special dayyyy you know why?" 
    call screen Split_1

screen Split_1():
    modal True
    tag selection
    frame:
        xalign 0.5
        yalign 0.5
        background "#0009"
        padding (10, 10, 10, 10)
        vbox:
            spacing 30
            text "Make your choice:" color "#fff" size 40
            textbutton "Beg to sleep in." action [Jump("Beg_to_sleep_in")] text_color "#fff" text_size 35
            textbutton "Sarcastically question why." action [Jump("Sarcastically_question_why")] text_color "#fff" text_size 35

label Beg_to_sleep_in:
    show you sleepy with fade
    show mom excited with fade
    u "It’s because it's the day you let me sleep in the WHOLE day, right!"
    m " Ya right Mr, you do that every Saturday. Speaking of which, I want you to lay off those video games. They are gonna make you go blind!"
    u "Mom that's like so not true! You really shouldn’t believe everything you read off Facebook" 
    m "Shush young man. That's enough out of you! We are going off the original point. I wanted to tell you about this day!"
    u "Fineeeeeee, sorry Mom. Tell me what makes my 18th day so special."
    jump tie_in_1

label Sarcastically_question_why:
    show you sleepy with fade
    show mom excited with fade 
    u "You: Ugggggghhh! No please tell me mom, I can’t wait to find out why this day is so special, NOT."
    m "Always so grumpy in the morning. *Hmph* You definitely take off your Dad. He is impossible to talk to until he has had his coffee." 
    u "Ya, ya, ya. I have his eyes and his hair too Mom. You bring it up every time we talk about Dad."
    m "It’s because you doooooo sweetheart. Now that your 18 too you are your own man."
    show mom cry 
    u "Awwww mom come on don’t cry! Come on tell me what is so special about today I really wanna know now."
    jump tie_in_1

label tie_in_1:
    show you normal with fade
    show mom excited with fade 
    m "Wellll, son today being your 18th birthday means you are finally classified as a monster hunter!"
    call screen Split_2

screen Split_2():
    modal True
    tag selection
    frame:
        xalign 0.5
        yalign 0.5
        background "#0009"
        padding (10, 10, 10, 10)
        vbox:
            spacing 30
            text "Make your choice:" color "#fff" size 40
            textbutton "Ask what is a monster hunter?" action [Jump("Ask_what_is_a_monster_hunter")] text_color "#fff" text_size 35
            textbutton "Ask why you are a monster hunter now?" action [Jump("Ask_why_you_are_a_monster_hunter_now")] text_color "#fff" text_size 35

label Ask_what_is_a_monster_hunter:
    u "Monster hunter? What is that Mom?"
    m "You don’t know hun? That’s a shocker! A monster hunter is a person who is 18 years old and it;s there job to go and fight monster to either capture them to make them into DELICIOUS meals or keep them as pets!"
    show you shocked
    u "SAY WHAT NOW!" 
    jump tie_in_2

label Ask_why_you_are_a_monster_hunter_now:
    u "Wait, is it just now that I am 18, a monster hunter?"
    m "Hmmm. That is a good question I don’t really know. I guess it boils down to tradition since the early 90’s and the boom in monster population has to do with it? As for it only being only a thing when you are 18 is a complete unknown for me haha. Just be glad you are one love!"
    jump Ask_what_is_a_monster_hunter
    
label tie_in_2:
    show you normal
    show mom kiss 
    m "Ohhhhh enough talk dear it is already 10:00 am. You're gonna be late for your meeting with Professor Mac! He is down the street, at the Solis lab. Hurry now love, *kiss* enjoy your adventure. Don’t forget your bike or else you won’t be able to get there."
    hide Mom kiss with fade 
    call screen Split_3

screen Split_3():
    modal True
    tag selection
    frame:
        xalign 0.5
        yalign 0.5
        background "#0009"
        padding (10, 10, 10, 10)
        vbox:
            spacing 30
            text "Make your choice:" color "#fff" size 40
            textbutton "Pick up bike from back yard." action [Jump("Pick_up_bike_from_back_yard")] text_color "#fff" text_size 35
            textbutton "Ignore all of what your mom said and sleep in." action [Jump("Ignore_all_of_what_your_mom_said_and_sleep_in")] text_color "#fff" text_size 35

label Pick_up_bike_from_back_yard:
    u "My bike is in the garage better go get it quick, so I am not too late."
    $ inventory.append("Bike")
    jump narration

label Ignore_all_of_what_your_mom_said_and_sleep_in:
    u "Ehhhh this is all a dream and if not who cares if I really become a monster hunter right?"
    "You go back to sleep and miss out on being a monster hunter. GAME OVER."
    return 



