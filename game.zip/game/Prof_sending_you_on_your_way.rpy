label Near_conclusion_1: 
    show you happy
    u " Alright gang where to first!"
    show mike happy
    b "Bro, I hear there is a wicked cool monster in the highlands. They say it like a 7ft snake."
    g "Ewwww, them snakes is all nasty-like. I reckon I done heard 'bout a critter that’s said to dwell at a big ol' beach. Ain’t too sure if it’s a giant crab monster or a lobster, but like we say, tomato, tomato." 
    u "Hmmm well, the game developer is very tired and out of budget so it seems like we only have time to do one adventure."
    
menu:
    "Agree with Mike and go to the highlands."
    "Agree with Millie and go to beach."

    "Agree with Mike and go to the highlands.":
        jump Agree_with_Mike_and_go_to_the_highlands
    "Agree with Millie and go to sea reef.":
        jump Agree_with_Millie_and_go_to_beach

label Agree_with_Mike_and_go_to_the_highlands:
    show you excited
    u "A SNAKE! That badass no matter if we keep it or eat it HAHA. First stop the highlands."
    show mike happy
    b "Bro I hear to that snakes taste like chicken!"
    show millie pout
    g "*Hmph*. Alrighty then, but y’all gonna do all the tusslin’. I’m just taggin’ along 'cause it’s gonna be a rip-snortin’ fight, and I’m hopin’ for some vittles afterward."
    scene bg highlands
    show mike normal
    b "WOAHHHH! This place is packed to the brim with grass. Why they even call it the highland. Should be called the grasslands."
    show millie normal
    g "Y’all got a good point there, Mike. Guess it’s kinda like that Iceland and Greenland thing, huh?"
    show you normal
    u "Beside the whole name scenario. How should we go about finding this snake monster you mentioned earlier Mike."

menu: 
    "Search with hands."
    "Use Scanner."

    "Search with hands.":
        jump Search_with_hands
    "Use Scanner.":
        jump Use_Scanner

label Search_with_hands: 
    g "I mean god gave us hands for a reason right? Ough’ to use them!" 
    "-your team searches for a hour-"
    show you thinking
    u "Ummm, Millie no offense but we been at this for a hour maybe we try something else right."
    show mike angry
    b "FUCK WHAT MILLIE SAYS! WE DOING SOMETHING ELSE!"
    show millie pout
    g "Calm down, Mike, ain't nobody twistin' your arm to go searchin’, good grief. Why don’t we just fire up that scanner the professor handed us?"
    jump Use_Scanner

label Use_scanner:
    show you happy 
    u "Ohhh right the scanner. Pretty sure this is the exact reason Prof. Mac gave it to us. Lets boot this baby up!"
    "Monster detected 3 miles SE"
    show mike happy
    b "Right on man! That’s what I'm talking about! Let's head over there now"
    show millie happy
    g "I agree I'm starvingggg!"
    "Group travels 3 miles SE"
    show you happy
    u "Ohh shitttt! Look there it is! Dam Mike you weren’t kidding that thing has to be at least 8 ft tall."
    show you excited
    u "LET'S BATTLE!"
    jump battle_sequence1

label Agree_with_Millie_and_go_to_beach:
    show you happy 
    u "A beach adventure. Now that is a one in a lifetime adventure. Sorry Mike, I also owe Millie you know for being gone for 12-ish years."
    show mike happy
    b "Ehhh honestly as long as we're fighting a badass monster I don’t really care lol! Let’s just hurry up and get to it!"
    show millie happy 
    g "YEEHAW! Take that, Mike, my pick done won! Just wish I had me a cute lil' bikini to go with the fun, but shoot, guess I ain't got one."

    scene bg beach 
    show you happy
    u "Alright! Drop anchors were here haha. Only problem is now how do we find that dang crab!"

menu: 
    "Ask Millie."
    "Ask Mike."

    "Ask Millie.":
        jump Ask_Millie
    "Ask Mike.":
        jump Ask_Mike

label Ask_Millie:
    show millie thinking
    g "Ain't no doubt we oughta use that fishin' bait the prof handed us. I reckon it’ll work like a charm, no two ways about it!"
    jump Use_bait

label Ask_Mike:
    show mike smug
    b "Heh Don’t worry dawg I came prepared! I saw somewhere on twitter this ancient Mayan fishing breeding call. It should make that crab coming running to us!"
    b "humuhumunukunukuapua'a"
    show you laugh
    u "HAHAHAHA, Mike no offense but that is got to be by far the dumbest mating call. You finding it off twitter should of let you know it wasn’t gonna work."
    show mike angry
    b "SHUT UP MAN!"
    show millie happy
    g "Well I'll be, Mike, you sure are a fool! Ain't no doubt we oughta use that fishin' bait the prof handed us. I reckon it’ll work like a charm, no two ways about it!"
    jump Use_bait

label Use_bait: 
    show you normal 
    u "Right right. Let see, here it is! Glad we are finally gonna be using it has been making my bag smell like old fish food!"
    "Ocean RUMBLES"
    show mike scared
    b "Ummm y'all hear that right?"
    show millie happy
    g "YEEHAW! Looky there, it's that crab! Hurry up, grab Infernox and let’s stomp that critter 'fore it gets us too!"
    show you normal
    u "ON IT! Go Infernox!"
    jump battle_sequence2



# Battle Interface 
label battle_sequence1:
    show screen battle_interface1
    $ result = ui.interact()

    if result == "Attack":
        hide screen battle_interface1
        "You launch an attack with Infernox!"
        "The wandering monster it hit. It looks fightened and confused."
        $ opponent_hp -= 20
        if opponent_hp <= 0:
            "The wandering creature collapses, terrified."
            hide screen battle_interface1
            jump victory1
        else:
            "The wandering creature is still standing!"
            jump battle_sequence1

    elif result == "Spare":
        hide screen battle_interface1
        "The wandering creature doesn't yeild to mercy"
        $ player_hp += 0
        if player_hp == 100:
            "The creatures demand a fight."
            hide screen battle_interface1
            jump battle_sequence1
        else:
            "Both creatures are studying one another."
            jump battle_sequence1

    elif result == "Capture":
        hide screen battle_interface1
        "The wandering creature seems to know what is about to happan"
        $ player_hp += 0
        if opponet_hp == 20:
            "You throw the capsule and capture the monster."
            jump capture1
        else:
            "You throw a capsule at the monster but it breaks free."
            jump battle_sequence1

    elif result == "Run":
        hide screen battle_interface1
        "You try to escape, but the creature blocks you!"
        jump battle_sequence1

label victory1:
    "You have defeat the monster and inserted it into your mosnter capsule. What to do with it now?"
menu: 
    "Eat Monster."
    "Leave captured as a pet."

    "Eat Monster.":
        jump Eat_Monster1
    "Leave captured as a pet.":
        jump Leave_captured_as_a_pet1

label Eat_Monster1:
    show you happy
    u "With all the running and looking around we did I rather eat a tasty meal! Lets cook this big snake"
    show mike happy
    b "Niceeee, that was the only right choice haha."
    show millie happy
    g "Reckon it woulda been nice to have him as a critter, but shoot, come sundown, we still grabbin' a mighty fine meal!"
    u "Now all that left to do is cook this guy. I know I have that cooking kit on me somewhere. Here it is!?"
    u "Time for some tasty snake soup!"
    "Till next time Hunter's!"

label Leave_captured_as_a_pet1: 
    show you excited
    u "A giant snake! Why the hell wouldn’t I capture it. Imagine all the trouble we can get into!"
    show mike excited
    b "Fuck yaaa dude. Hurry up and throw you mosnter capsule at it before it escapes or something!"
    show millie happy
    g "Yessiree, ya got 'im! Another critter checkin' in the books. I just pray he plays nice with Infernox even after that ruckus they just had."
    "Till next time Hunter's!"


# Battle Interface 
label battle_sequence2:
    show screen battle_interface2
    $ result = ui.interact()

    if result == "Attack":
        hide screen battle_interface2
        "You launch an attack with Infernox!"
        "The wandering monster it hit. It looks fightened and confused."
        $ opponent_hp -= 20
        if opponent_hp <= 0:
            "The wandering creature collapses, terrified."
            hide screen battle_interface2
            jump victory2
        else:
            "The wandering creature is still standing!"
            jump battle_sequence2

    elif result == "Spare":
        hide screen battle_interface2
        "The wandering creature doesn't yeild to mercy"
        $ player_hp += 0
        if player_hp == 100:
            "The creatures demand a fight."
            hide screen battle_interface2
            jump battle_sequence2
        else:
            "Both creatures are studying one another."
            jump battle_sequence2

    elif result == "Capture":
        hide screen battle_interface2
        "The wandering creature seems to know what is about to happan"
        $ player_hp += 0
        if opponet_hp == 20:
            "You throw the capsule and capture the monster."
            jump capture2
        else:
            "You throw a capsule at the monster but it breaks free."
            jump battle_sequence2

    elif result == "Run":
        hide screen battle_interface2
        "You try to escape, but the creature blocks you!"
        jump battle_sequence2

label victory2:
    "You have defeat the monster and inserted it into your mosnter capsule. What to do with it now?"

menu: 
    "Eat Monster."
    "Leave captured as a pet."

    "Eat Monster.":
        jump Eat_Monster2
    "Leave captured as a pet.":
        jump Leave_captured_as_a_pet2

label Eat_Monster2:
    show you happy
    u "With all the running and looking around we did I rather eat a tasty meal! Lets cook this big crab"
    show mike happy
    b "Niceeee, that was the only right choice haha."
    show millie happy
    g "Reckon it woulda been nice to have him as a critter, but shoot, come sundown, we still grabbin' a mighty fine meal!"
    u "Now all that left to do is cook this guy. I know I have that cooking kit on me somewhere. Here it is!?"
    u "Time for some tasty snake soup!"
    "Till next time Hunter's!"

label Leave_captured_as_a_pet2: 
    show you excited
    u "A giant Crab! Why the hell wouldn’t I capture it. Imagine all the trouble we can get into!"
    show mike excited
    b "Fuck yaaa dude. Hurry up and throw you mosnter capsule at it before it escapes or something!"
    show millie happy
    g "Yessiree, ya got 'im! Another critter checkin' in the books. I just pray he plays nice with Infernox even after that ruckus they just had."
    "Till next time Hunter's!"